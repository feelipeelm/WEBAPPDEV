<?php
include("conexion.php");

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = $_POST['num'];

    $sql = "DELETE FROM departamentos WHERE NumDepartamento = '$num'";

    if ($conn->query($sql)) {
        $mensaje = "Departamento eliminado.";
    } else {
        $mensaje = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Departamento</title>
</head>
<body>
    <h1>Eliminar Departamento</h1>
    <?php echo "<p>$mensaje</p>"; ?>
    <form method="post">
        Nº Departamento a eliminar: <input type="number" name="num" required><br>
        <input type="submit" value="Eliminar">
    </form>
    <form action="index.php" method="get">
    <input type="submit" value="Volver al inicio">
</form>

</body>
</html>
