<?php
include("conexion.php");

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = $_POST['num'];
    $presupuesto = $_POST['presupuesto'];
    $nombre = $_POST['nombre'];

    $sql = "UPDATE departamentos SET Presupuesto = '$presupuesto', NombreDepartamento = '$nombre' 
            WHERE NumDepartamento = '$num'";

    if ($conn->query($sql)) {
        $mensaje = "Departamento actualizado.";
    } else {
        $mensaje = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actualizar Departamento</title>
</head>
<body>
    <h1>Actualizar Departamento</h1>
    <?php echo "<p>$mensaje</p>"; ?>
    <form method="post">
        Nº Departamento: <input type="number" name="num" required><br>
        Nuevo Presupuesto: <input type="number" step="0.1" name="presupuesto" required><br>
        Nuevo Nombre: <input type="text" name="nombre" required><br>
        <input type="submit" value="Actualizar">
    </form>
    <form action="index.php" method="get">
    <input type="submit" value="Volver al inicio">
</form>

</body>
</html>
