<?php
include("conexion.php");

$presupuesto = isset($_GET['presupuesto']) ? $_GET['presupuesto'] : '';
$numero = isset($_GET['numero']) ? $_GET['numero'] : '';

$sql = "SELECT * FROM departamentos WHERE 1=1";
if ($presupuesto != '') {
    $sql .= " AND Presupuesto >= $presupuesto";
}
if ($numero != '') {
    $sql .= " AND NumDepartamento = $numero";
}

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Filtrar Departamentos</title>
</head>
<body>
    <h1>Filtrar Departamentos</h1>
    <form method="get">
        Presupuesto mínimo: <input type="number" name="presupuesto" step="0.1"><br>
        Número de departamento: <input type="number" name="numero"><br>
        <input type="submit" value="Filtrar">
    </form>

    <table border="1">
        <tr>
            <th>Número</th>
            <th>Nombre</th>
            <th>Presupuesto</th>
            <th>Centro</th>
        </tr>
        <?php
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $fila["NumDepartamento"] . "</td>";
                echo "<td>" . $fila["NombreDepartamento"] . "</td>";
                echo "<td>" . $fila["Presupuesto"] . "</td>";
                echo "<td>" . $fila["NumCentro"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No se encontraron resultados</td></tr>";
        }
        ?>
    </table>
    <form action="index.php" method="get">
    <input type="submit" value="Volver al inicio">
</form>

</body>
</html>
