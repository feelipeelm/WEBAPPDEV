<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Empresa</title>
</head>
<body>
    <h1>Gestión de Empresa</h1>
    <ul>
        <li><a href="mostrar_centros.php">Mostrar Centros</a></li>
        <li><a href="filtrar_departamentos.php">Filtrar Departamentos</a></li>
        <li><a href="agregar_departamento.php">Agregar Departamento</a></li>
        <li><a href="eliminar_departamento.php">Eliminar Departamento</a></li>
        <li><a href="actualizar_departamento.php">Actualizar Departamento</a></li>
    </ul>
</body>
</html>
