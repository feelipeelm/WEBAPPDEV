<?php
include("conexion.php");

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = $_POST['num'];
    $centro = $_POST['centro'];
    $director = $_POST['director'];
    $tipo = $_POST['tipo'];
    $presupuesto = $_POST['presupuesto'];
    $dependiente = $_POST['dependiente'];
    $nombre = $_POST['nombre'];

    $sql = "INSERT INTO departamentos (NumDepartamento, NumCentro, DirecDepartamento, TipoDireccion, Presupuesto, DepDependiente, NombreDepartamento) 
            VALUES ('$num', '$centro', '$director', '$tipo', '$presupuesto', " . ($dependiente ? "'$dependiente'" : "NULL") . ", '$nombre')";

    if ($conn->query($sql)) {
        $mensaje = "Departamento agregado correctamente.";
    } else {
        $mensaje = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Departamento</title>
</head>
<body>
    <h1>Agregar Departamento</h1>
    <?php echo "<p>$mensaje</p>"; ?>
    <form method="post">
        Nº Departamento: <input type="number" name="num" required><br>
        Nº Centro: <input type="number" name="centro" required><br>
        Director: <input type="number" name="director" required><br>
        Tipo Dirección (P/F): <input type="text" name="tipo" maxlength="1" required><br>
        Presupuesto: <input type="number" step="0.1" name="presupuesto" required><br>
        Departamento Dependiente: <input type="number" name="dependiente"><br>
        Nombre: <input type="text" name="nombre" required><br>
        <input type="submit" value="Agregar">
    </form>
</body>
<form action="index.php" method="get">
    <input type="submit" value="Volver al inicio">
</form>

</html>
