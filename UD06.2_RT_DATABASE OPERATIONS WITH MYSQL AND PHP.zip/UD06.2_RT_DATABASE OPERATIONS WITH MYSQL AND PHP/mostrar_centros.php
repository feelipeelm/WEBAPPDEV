<?php
include("conexion.php");

$sql = "SELECT * FROM centros";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Centros</title>
</head>
<body>
    <h1>Centros</h1>
    <table border="1">
        <tr>
            <th>Número</th>
            <th>Nombre</th>
            <th>Dirección</th>
        </tr>
        <?php
        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $fila["NumCentro"] . "</td>";
                echo "<td>" . $fila["NombreCentro"] . "</td>";
                echo "<td>" . $fila["DireccionCentro"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No hay centros</td></tr>";
        }
        ?>
    </table>
    <form action="index.php" method="get">
    <input type="submit" value="Volver al inicio">
</form>

</body>
</html>
