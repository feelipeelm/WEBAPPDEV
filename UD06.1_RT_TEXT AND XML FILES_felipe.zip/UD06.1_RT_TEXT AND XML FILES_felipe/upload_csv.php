<?php
$csvFile = "Grocery_Inventory.csv";
$xmlFile = "data/products.xml";

// verifica que el archivoexista
if (!file_exists($csvFile)) {
    die("El archivo CSV no se encuentra.");
}

// abre el archivo CSV
if (($handle = fopen($csvFile, "r")) !== false) {
    $headers = fgetcsv($handle, 1000, ",");

    $xml = new SimpleXMLElement('<Products/>');

    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
        $product = $xml->addChild('product');

        foreach ($headers as $index => $header) {
            // limpia espacios y caracteres especiales
            $field = preg_replace('/[^a-zA-Z0-9_]/', '', str_replace(' ', '_', $header));
            $product->addChild($field, htmlspecialchars($data[$index]));
        }
    }

    fclose($handle);

    // guardaa el XML
    $xml->asXML($xmlFile);

    echo "Archivo XML creado correctamente en: <code>$xmlFile</code><br>";
    echo "<a href='index.php'>Volver al menú</a>";
} else {
    echo "No se pudo abrir el archivo CSV.";
}
?>
