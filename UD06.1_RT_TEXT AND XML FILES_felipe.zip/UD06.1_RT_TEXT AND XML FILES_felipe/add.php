<?php
$xmlFile = 'data/products.xml';

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!file_exists($xmlFile)) {
        die("El archivo XML no se encontró en: " . realpath($xmlFile));
    }

    $xml = simplexml_load_file($xmlFile);

    // Crear nuevo producto
    $nuevo = $xml->addChild('product');
    $nuevo->addChild('Product_Name', $_POST['Product_Name']);
    $nuevo->addChild('Catagory', $_POST['Catagory']);
    $nuevo->addChild('Supplier_Name', $_POST['Supplier_Name']);
    $nuevo->addChild('Warehouse_Location', $_POST['Warehouse_Location']);
    $nuevo->addChild('Status', $_POST['Status']);
    $nuevo->addChild('Product_ID', $_POST['Product_ID']);
    $nuevo->addChild('Supplier_ID', $_POST['Supplier_ID']);
    $nuevo->addChild('Date_Received', $_POST['Date_Received']);
    $nuevo->addChild('Last_Order_Date', $_POST['Last_Order_Date']);
    $nuevo->addChild('Expiration_Date', $_POST['Expiration_Date']);
    $nuevo->addChild('Stock_Quantity', $_POST['Stock_Quantity']);
    $nuevo->addChild('Reorder_Level', $_POST['Reorder_Level']);
    $nuevo->addChild('Reorder_Quantity', $_POST['Reorder_Quantity']);
    $nuevo->addChild('Unit_Price', $_POST['Unit_Price']);
    $nuevo->addChild('Sales_Volume', $_POST['Sales_Volume']);
    $nuevo->addChild('Inventory_Turnover_Rate', $_POST['Inventory_Turnover_Rate']);
    $nuevo->addChild('percentage', $_POST['percentage']);

    // Guardar XML
    $xml->asXML($xmlFile);

    echo "<p>Producto agregado correctamente.</p>";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Añadir Producto</title>
</head>
<body>
    <h1>Añadir Producto</h1>

    <form method="post">
        <label>Nombre del Producto: <input type="text" name="Product_Name" required></label><br>
        <label>Categoría: <input type="text" name="Catagory" required></label><br>
        <label>Proveedor: <input type="text" name="Supplier_Name" required></label><br>
        <label>Ubicación del Almacén: <input type="text" name="Warehouse_Location" required></label><br>
        <label>Estado: <input type="text" name="Status" required></label><br>
        <label>ID Producto: <input type="text" name="Product_ID" required></label><br>
        <label>ID Proveedor: <input type="text" name="Supplier_ID" required></label><br>
        <label>Fecha de Recepción: <input type="date" name="Date_Received" required></label><br>
        <label>Último Pedido: <input type="date" name="Last_Order_Date" required></label><br>
        <label>Fecha de Caducidad: <input type="date" name="Expiration_Date" required></label><br>
        <label>Stock: <input type="number" name="Stock_Quantity" required></label><br>
        <label>Nivel de Reorden: <input type="number" name="Reorder_Level" required></label><br>
        <label>Cantidad de Reorden: <input type="number" name="Reorder_Quantity" required></label><br>
        <label>Precio Unitario: <input type="text" name="Unit_Price" required></label><br>
        <label>Volumen de Ventas: <input type="number" name="Sales_Volume" required></label><br>
        <label>Tasa de Rotación: <input type="text" name="Inventory_Turnover_Rate" required></label><br>
        <label>Porcentaje: <input type="text" name="percentage" required></label><br><br>

        <button type="submit">Agregar Producto</button>
        <a href="index.php">
                <button type="button">Volver al menú principal</button>
        </a>
    </form>
</body>
</html>
