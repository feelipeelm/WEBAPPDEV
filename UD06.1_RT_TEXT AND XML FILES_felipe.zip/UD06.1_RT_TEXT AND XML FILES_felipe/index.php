<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Inventario</title>
</head>
<body>
    <h1>Gestión de Inventario</h1>
    <ul>
        <li><a href="upload_csv.php">Subir archivo CSV y generar XML</a></li>
        <li><a href="show.php">Ver y filtrar productos</a></li>
        <li><a href="add.php">Añadir producto</a></li>
        <li><a href="delete.php">Eliminar producto</a></li>
        <li><a href="modify.php">Modificar producto</a></li>
    </ul>
</body>
</html>
