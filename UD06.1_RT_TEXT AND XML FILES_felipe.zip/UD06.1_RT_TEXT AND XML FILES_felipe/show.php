<?php
$xmlFile = 'data/products.xml';

if (!file_exists($xmlFile)) {
    die("El archivo XML no se encontró en: " . realpath($xmlFile));
}

$xml = simplexml_load_file($xmlFile);

// Obtenemos categorías únicas
$categorias = [];
foreach ($xml->product as $producto) {
    $cat = (string) $producto->Catagory;
    if (!in_array($cat, $categorias)) {
        $categorias[] = $cat;
    }
}

// Obtenemos filtros del formulario
$filtroCategoria = $_GET['categoria'] ?? '';
$filtroUltimoPedido = $_GET['ultimo_pedido'] ?? '';
$filtroCaducidad = $_GET['caducidad'] ?? '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Filtrar Productos</title>
</head>
<body>
    <h1>Filtrar Productos</h1>

    <form method="GET">
        <label for="categoria">Categoría:</label>
        <select name="categoria" id="categoria">
            <option value="">-- Todas --</option>
            <?php foreach ($categorias as $categoria): ?>
                <option value="<?= $categoria ?>" <?= ($filtroCategoria == $categoria) ? 'selected' : '' ?>>
                    <?= $categoria ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="ultimo_pedido">Fecha último pedido (YYYY-MM-DD):</label>
        <input type="date" name="ultimo_pedido" id="ultimo_pedido" value="<?= $filtroUltimoPedido ?>">

        <label for="caducidad">Fecha caducidad (YYYY-MM-DD):</label>
        <input type="date" name="caducidad" id="caducidad" value="<?= $filtroCaducidad ?>">

        <button type="submit">Filtrar</button>
    </form>

    <h2>Resultados</h2>

    <table border="1">
        <tr>
            <th>Producto</th>
            <th>Categoría</th>
            <th>Fecha Último Pedido</th>
            <th>Fecha Caducidad</th>
        </tr>

        <?php
        $resultados = 0;
        foreach ($xml->product as $p) {
            $cat = (string) $p->Catagory;
            $fechaPedido = date('Y-m-d', strtotime((string) $p->Last_Order_Date));
            $fechaCad = date('Y-m-d', strtotime((string) $p->Expiration_Date));

            if (
                ($filtroCategoria === '' || $filtroCategoria === $cat) &&
                ($filtroUltimoPedido === '' || $fechaPedido === $filtroUltimoPedido) &&
                ($filtroCaducidad === '' || $fechaCad === $filtroCaducidad)
            ) {
                echo "<tr>";
                echo "<td>{$p->Product_Name}</td>";
                echo "<td>{$cat}</td>";
                echo "<td>{$fechaPedido}</td>";
                echo "<td>{$fechaCad}</td>";
                echo "</tr>";
                $resultados++;
            }
        }

        if ($resultados === 0) {
            echo "<tr><td colspan='4'>No se encontraron productos con esos filtros.</td></tr>";
        }
        ?>
    </table>
    <a href="index.php">
            <button type="button">Volver al menú principal</button>
    </a>
</body>
</html>
