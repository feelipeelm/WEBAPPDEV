<?php
$xmlFile = 'data/products.xml';

function cargarXML($ruta) {
    if (!file_exists($ruta)) {
        die("Archivo XML no encontrado en: " . realpath($ruta));
    }
    return simplexml_load_file($ruta);
}

$producto = null;
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $xml = cargarXML($xmlFile);

    if (isset($_POST['buscar'])) {
        // Buscar producto para mostrar datos
        $idBuscar = trim($_POST['Product_ID']);
        foreach ($xml->product as $p) {
            if ((string)$p->Product_ID === $idBuscar) {
                $producto = $p;
                break;
            }
        }
        if (!$producto) {
            $mensaje = "Producto con ID $idBuscar no encontrado.";
        }
    } elseif (isset($_POST['modificar'])) {
        // Modificar producto
        $idModificar = trim($_POST['Product_ID']);
        $encontrado = false;

        foreach ($xml->product as $p) {
            if ((string)$p->Product_ID === $idModificar) {
                $encontrado = true;
                // Actualizamos sólo si hay valor diferente y no vacío
                foreach ($_POST as $campo => $valor) {
                    if ($campo != 'Product_ID' && $campo != 'modificar' && $campo != 'buscar') {
                        if ($valor !== '') {
                            $p->$campo = $valor;
                        }
                    }
                }
                break;
            }
        }

        if ($encontrado) {
            $xml->asXML($xmlFile);
            $mensaje = "Producto modificado correctamente.";
        } else {
            $mensaje = "Producto con ID $idModificar no encontrado.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Producto</title>
</head>
<body>
    <h1>Modificar Producto</h1>

    <form method="post">
        <label>Ingrese Product_ID para buscar:
            <input type="text" name="Product_ID" value="<?php echo isset($_POST['Product_ID']) ? htmlspecialchars($_POST['Product_ID']) : '' ?>" required>
        </label>
        <button type="submit" name="buscar">Buscar</button>
    </form>

    <?php if ($mensaje): ?>
        <p><?php echo $mensaje; ?></p>
    <?php endif; ?>

    <?php if ($producto): ?>
        <h2>Editar producto <?php echo htmlspecialchars($producto->Product_Name); ?></h2>
        <form method="post">
            <input type="hidden" name="Product_ID" value="<?php echo htmlspecialchars($producto->Product_ID); ?>">

            <?php
            // Mostrar todos los campos del producto para editar, excepto Product_ID (ya está oculto)
            foreach ($producto->children() as $campo => $valor) {
                if ($campo === 'Product_ID') continue;
                ?>
                <label><?php echo $campo; ?>:
                    <input type="text" name="<?php echo $campo; ?>" value="<?php echo htmlspecialchars($valor); ?>">
                </label><br>
                <?php
            }
            ?>
            <button type="submit" name="modificar">Guardar Cambios</button>
        </form>
    <?php endif; ?>

    <br><br>
    <a href="index.php"><button type="button">Volver al menú principal</button></a>
</body>
</html>
