<?php
$xmlFile = 'data/products.xml';

function cargarXML($ruta) {
    if (!file_exists($ruta)) {
        die("Archivo XML no encontrado en: " . realpath($ruta));
    }
    return simplexml_load_file($ruta);
}

// Eliminar por ID o de forma masiva
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $xml = cargarXML($xmlFile);
    $eliminados = 0;

    // Eliminar por Product_ID
    if (!empty($_POST['Product_ID'])) {
        foreach ($xml->product as $i => $p) {
            if ((string)$p->Product_ID === $_POST['Product_ID']) {
                unset($xml->product[$i]);
                $eliminados++;
            }
        }
    }

    // Eliminar por categoría
    if (!empty($_POST['Catagory'])) {
        foreach ($xml->product as $i => $p) {
            if ((string)$p->Catagory === $_POST['Catagory']) {
                unset($xml->product[$i]);
                $eliminados++;
            }
        }
    }

    // Eliminar por precio
    if (!empty($_POST['Unit_Price'])) {
        $precio = floatval(str_replace(['$', ','], '', $_POST['Unit_Price']));
        foreach ($xml->product as $i => $p) {
            $precioProd = floatval(str_replace(['$', ','], '', (string)$p->Unit_Price));
            if ($precioProd <= $precio) {
                unset($xml->product[$i]);
                $eliminados++;
            }
        }
    }

    // Eliminar por volumen de ventas
    if (!empty($_POST['Sales_Volume'])) {
        foreach ($xml->product as $i => $p) {
            if ((int)$p->Sales_Volume <= (int)$_POST['Sales_Volume']) {
                unset($xml->product[$i]);
                $eliminados++;
            }
        }
    }

    // Guardar cambios si hubo eliminaciones
    if ($eliminados > 0) {
        $xml->asXML($xmlFile);
        echo "<p>Se eliminaron $eliminados producto(s).</p>";
    } else {
        echo "<p>No se encontró ningún producto que coincida con los criterios.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Producto</title>
</head>
<body>
    <h1>Eliminar Producto</h1>
    <form method="post">
        <label>Eliminar por ID de Producto: <input type="text" name="Product_ID"></label><br><br>

        <h3>O eliminar en masa por:</h3>
        <label>Categoría: <input type="text" name="Catagory"></label><br>
        <label>Precio menor o igual a: <input type="text" name="Unit_Price"></label><br>
        <label>Volumen de ventas menor o igual a: <input type="number" name="Sales_Volume"></label><br><br>

        <button type="submit">Eliminar</button>
    </form>

    <br><br>
    <a href="index.php">
        <button type="button">Volver al menú principal</button>
    </a>
</body>
</html>
