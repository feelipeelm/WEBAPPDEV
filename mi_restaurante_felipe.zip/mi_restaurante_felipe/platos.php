<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include 'productos.php';

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($platos as $clave => $producto) {
        if (!empty($_POST[$clave])) {
            $cantidad = intval($_POST[$clave]);
            if ($cantidad > 0) {
                $_SESSION['carrito'][$clave] = ($_SESSION['carrito'][$clave] ?? 0) + $cantidad;
            }
        }
    }

    // Guardar favorito
    if (!empty($_POST['favorito'])) {
        setcookie('favorito_plato_' . $_SESSION['usuario'], $_POST['favorito'], time() + 7 * 24 * 60 * 60);
    }
    header('Location: platos.php');
    exit;
}

$favorito = $_COOKIE['favorito_plato_' . $_SESSION['usuario']] ?? '';
?>

<h2>Platos Principales</h2>
<form method="post">
    <?php foreach ($platos as $clave => $producto): ?>
        <p>
            <?= $producto['nombre'] ?> (<?= $producto['precio'] ?> €)
            - Añadir:
            <input type="number" name="<?= $clave ?>" value="0" min="0">
            <label>
                <input type="radio" name="favorito" value="<?= $clave ?>" <?= ($favorito === $clave) ? 'checked' : '' ?>>
                Favorito
            </label>
        </p>
    <?php endforeach; ?>
    <button type="submit">Añadir al carrito</button>
</form>

<p><a href="postres.php">Ir a postres</a> | <a href="bebidas.php">Ir a bebidas</a> | <a href="resumen.php">Ver carrito</a> | <a href="index.php">Volver al inicio</a></p>


Muestra los platos.

Permite añadir unidades al carrito (sesión).

Permite marcar un plato favorito (cookie).

Guarda todo en la sesión o cookie y redirige para evitar recargar el formulario.

