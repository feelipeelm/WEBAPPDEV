<?php
$usuarios_validos = [
    'juan' => '1234',
    'maria' => 'abcd',
    'laura'   => 'laura'
];
//Guarda usuarios válidos. Se incluye desde login.php.
?>






