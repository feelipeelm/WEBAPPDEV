<?php
session_start();
session_unset();
session_destroy();
setcookie('usuario', '', time() - 3600); 
header('Location: login.php');
exit;
//Este archivo elimina la sesión y la cookie, y redirige al login.