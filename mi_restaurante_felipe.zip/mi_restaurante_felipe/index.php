<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
?>

<h1>Bienvenido, <?= $_SESSION['usuario'] ?>!</h1>
<p><a href="platos.php">Ver Platos Principales</a></p>
<p><a href="postres.php">Ver Postres</a></p>
<p><a href="bebidas.php">Ver Bebidas</a></p>
<p><a href="resumen.php">Ver Carrito / Finalizar</a></p>
<p><a href="logout.php">Cerrar sesión</a></p>
