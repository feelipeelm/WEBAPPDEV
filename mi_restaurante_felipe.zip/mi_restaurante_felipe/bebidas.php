<?php
session_start(); // Inicia la sesión para usar variables de sesión

// Si el usuario no ha iniciado sesión, lo redirige al login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include 'productos.php'; // Incluye el archivo donde están definidos los arrays de productos (platos, postres, bebidas)


// Si se ha enviado el formulario por método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Recorremos todas las bebidas
    foreach ($bebidas as $clave => $producto) {

        // Si el campo del formulario para esta bebida no está vacío
        if (!empty($_POST[$clave])) {

            // Convertimos a número entero la cantidad introducida
            $cantidad = intval($_POST[$clave]);

            // Si la cantidad es mayor que 0, la añadimos al carrito
            if ($cantidad > 0) {
                // Si ya había esa bebida en el carrito, sumamos la cantidad nueva
                $_SESSION['carrito'][$clave] = ($_SESSION['carrito'][$clave] ?? 0) + $cantidad;
            }
        }
    }

    // Recargamos la misma página para evitar reenvío del formulario al refrescar
    header('Location: bebidas.php');
    exit;
}
?>


<h2>Bebidas</h2>
<form method="post">
    <?php foreach ($bebidas as $clave => $producto): ?>
        <p>
            <?= $producto['nombre'] ?> (<?= $producto['precio'] ?> €)
            - Añadir:
            <input type="number" name="<?= $clave ?>" value="0" min="0">
        </p>
    <?php endforeach; ?>
    <button type="submit">Añadir al carrito</button>
</form>

<p><a href="platos.php">Ir a platos</a> | <a href="postres.php">Ir a postres</a> | <a href="resumen.php">Ver carrito</a> | <a href="index.php">Volver al inicio</a></p>
