<?php
session_start(); // Inicia la sesión para poder acceder a las variables de sesión

// Si el usuario no ha iniciado sesión, se le redirige al login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include 'productos.php'; // Incluye el archivo que contiene los arrays de productos (platos, postres, bebidas)

// Une todos los productos en un solo array
$productos = array_merge($platos, $postres, $bebidas);

// Recupera el carrito de la sesión, si no existe se asigna un array vacío
$carrito = $_SESSION['carrito'] ?? [];

$total = 0; // Variable que guardará el total del pedido

// Si el usuario pulsa el botón "comprar"
if (isset($_POST['comprar'])) {
    $_SESSION['carrito'] = []; // Se vacía el carrito
    echo "<h2>¡Compra realizada con éxito!</h2>";
    echo "<p><a href='index.php'>Volver al inicio</a></p>";
    exit;
}

// Si el usuario pulsa el botón "eliminar"
if (isset($_POST['eliminar'])) {
    $clave = $_POST['eliminar']; // Se obtiene la clave (nombre del producto)
    unset($_SESSION['carrito'][$clave]); // Se elimina ese producto del carrito
    header('Location: resumen.php'); // Se recarga la página para mostrar el nuevo carrito
    exit;
}
?>


<h2>Resumen del pedido</h2>

<?php if (empty($carrito)): ?>
    <p>No hay productos en el carrito.</p>
<?php else: ?>
    <form method="post">
        <ul>
            <?php foreach ($carrito as $clave => $cantidad): ?>
                <li>
                    <?= $productos[$clave]['nombre'] ?> - <?= $cantidad ?> x <?= $productos[$clave]['precio'] ?> €
                    = <?= $cantidad * $productos[$clave]['precio'] ?> €
                    <button type="submit" name="eliminar" value="<?= $clave ?>">Quitar</button>
                </li>
                <?php $total += $cantidad * $productos[$clave]['precio']; ?>
            <?php endforeach; ?>
        </ul>
        <p><strong>Total: <?= $total ?> €</strong></p>
        <button type="submit" name="comprar">Finalizar compra</button>
    </form>
<?php endif; ?>

<p><a href="platos.php">Seguir eligiendo platos</a> | <a href="postres.php">postres</a> | <a href="bebidas.php">bebidas</a></p>
