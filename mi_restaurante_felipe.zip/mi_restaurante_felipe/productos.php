<?php
$platos = [
    'pollo_asado' => ['nombre' => 'Pollo Asado', 'precio' => 10],
    'pasta_carbonara' => ['nombre' => 'Pasta Carbonara', 'precio' => 8],
    'pescado' => ['nombre' => 'Pescado al Horno', 'precio' => 12]
];

$postres = [
    'tiramisu' => ['nombre' => 'Tiramisú', 'precio' => 4],
    'flan' => ['nombre' => 'Flan Casero', 'precio' => 3],
    'helado' => ['nombre' => 'Helado', 'precio' => 3]
];

$bebidas = [
    'agua' => ['nombre' => 'Agua Mineral', 'precio' => 1],
    'refresco' => ['nombre' => 'Refresco', 'precio' => 2],
    'vino' => ['nombre' => 'Vino Tinto', 'precio' => 5]
];
?>
