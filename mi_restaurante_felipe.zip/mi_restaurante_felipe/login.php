<?php
session_start();
include 'usuarios.php';

if (isset($_COOKIE['usuario'])) {
    // Usuario ya logueado anteriormente, redirigimos
    $_SESSION['usuario'] = $_COOKIE['usuario'];
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['usuario'] ?? '';
    $pass = $_POST['contrasena'] ?? '';

    if (isset($usuarios_validos[$user]) && $usuarios_validos[$user] === $pass) {
        // Guardamos cookie por 1 semana
        setcookie('usuario', $user, time() + 7 * 24 * 60 * 60);
        $_SESSION['usuario'] = $user;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Usuario o contraseña incorrectos';
    }
}
?>

<form method="post">
    <h2>Iniciar sesión</h2>
    <input type="text" name="usuario" placeholder="Usuario" required>
    <input type="password" name="contrasena" placeholder="Contraseña" required>
    <button type="submit">Entrar</button>
    <p style="color:red"><?= $error ?></p>
</form>



/* INICIO DEL SCRIPT
│
├── session_start()
│   └─ Inicia sesión PHP
│
├── include 'usuarios.php'
│   └─ Carga usuarios válidos
│
├── ¿Existe la cookie 'usuario'?
│   ├─ SÍ → Guarda en $_SESSION y redirige a index.php
│   └─ NO → Muestra formulario de login
│
└── ¿Se ha enviado el formulario?
    ├─ Recoge usuario y contraseña del POST
    ├─ ¿Usuario y contraseña válidos?
    │   ├─ SÍ:
    │   │   ├─ Crea cookie por 1 semana
    │   │   ├─ Guarda usuario en sesión
    │   │   └─ Redirige a index.php
    │   └─ NO:
    │       └─ Muestra mensaje de error
*/